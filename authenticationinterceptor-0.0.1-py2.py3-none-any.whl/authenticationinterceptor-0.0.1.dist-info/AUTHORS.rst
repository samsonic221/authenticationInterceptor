
Authors
=======

* samsonic - https://github.com/samsonic221/authentication_interceptor
